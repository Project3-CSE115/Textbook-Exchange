module BookExchangeApp {
    requires javafx.controls;
    requires javafx.fxml;

    // Allow JavaFX to instantiate Main via reflection
    exports BookExchangeApp to javafx.graphics;

    // Allow FXMLLoader to reflectively access controllers (and any @FXML fields/methods)
    opens BookExchangeApp to javafx.fxml;
}