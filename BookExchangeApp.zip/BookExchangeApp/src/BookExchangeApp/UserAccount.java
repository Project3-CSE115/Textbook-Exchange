package BookExchangeApp;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class UserAccount implements Archive {
    private ArrayList<User> users = new ArrayList<>();
    private ArrayList<Book> books = new ArrayList<>();
    private User thisUser = null;

    private final String USER_FILE = "users.txt";
    private final String BOOK_FILE = "books.txt";

    public UserAccount() {
    	users = new ArrayList<>();
        books = new ArrayList<>();
        loadData();
    }

    @Override
    public void saveData() {
        try (PrintWriter userOut = new PrintWriter(new FileWriter(USER_FILE));
             PrintWriter bookOut = new PrintWriter(new FileWriter(BOOK_FILE))) {

            for (User u : users) {
                userOut.println(u.toTxt());
            }
            for (Book b : books) {
                bookOut.println(b.toTxt());
            }
            System.out.println("Data saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    @Override
    public void loadData() {
        loadUsers();
        loadBooks();
    }

    private void loadUsers() {
        File file = new File(USER_FILE);
        if (!file.exists()) {
            System.out.println("No users file found. Starting fresh.");
            return;
        }
        try (Scanner reader = new Scanner(file)) {
            while (reader.hasNextLine()) {
                String line = reader.nextLine().trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\|");
                if (parts.length < 6) continue;

                if (parts[0].equals("Seller")) {
                    users.add(new Seller(parts[1], parts[2], parts[3], parts[4], parts[5]));
                } else {
                    users.add(new Student(parts[1], parts[2], parts[3], parts[4], parts[5]));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Users file not found.");
        }
    }

    private void loadBooks() {
        File file = new File(BOOK_FILE);
        if (!file.exists()) {
            System.out.println("No books file found. Starting with empty inventory.");
            return;
        }
        try (Scanner reader = new Scanner(file)) {
            while (reader.hasNextLine()) {
                String line = reader.nextLine().trim();
                if (line.isEmpty()) continue;
                String[] p = line.split("\\|");
                if (p.length >= 5) {
                    String title = p[0];
                    String author = p[1];
                    String condition = p[2];
                    double price = Double.parseDouble(p[3]);
                    String sellerID = p[4];
                    books.add(new Book(title, author, condition, price, sellerID));
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading books: " + e.getMessage());
        }
    }

    public boolean isIdDuplicate(String id) {
        return users.stream().anyMatch(u -> u.getID().equalsIgnoreCase(id));
    }

    public void registerUser(User u) {
        users.add(u);
        saveData();
    }

    public boolean login(String id, String pass) {
        for (User u : users) {
            if (u.getID().equals(id) && u.getPassword().equals(pass)) {
                thisUser = u;
                return true;
            }
        }
        return false;
    }

    public void listBook(Book b) throws DuplicateBookException {
        if (books.stream().anyMatch(book -> book.getTitle().equalsIgnoreCase(b.getTitle()))) {
            throw new DuplicateBookException("A book with title '" + b.getTitle() + "' is already listed!");
        }
        books.add(b);
        System.out.println("Book added to list: " + b.toTxt());
        saveData();
    }

    public void buyBook(String title) {
        books.removeIf(b -> b.getTitle().equalsIgnoreCase(title));
        saveData();
    }

    public User getThisUser() { return thisUser; }
    public ArrayList<Book> getBooks() { return books; }
    public void logout() { thisUser = null; }

    public User findUserByID(String id) {
        return users.stream().filter(u -> u.getID().equals(id)).findFirst().orElse(null);
    }
}