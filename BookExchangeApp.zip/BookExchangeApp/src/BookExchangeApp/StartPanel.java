package BookExchangeApp;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;

import java.io.IOException;

public class StartPanel {
    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void showLogin() throws IOException {
        loadScene("Login.fxml");
    }

    @FXML
    private void showSignUp() throws IOException {
        loadScene("SignUp.fxml");
    }

    void loadScene(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
        Parent root = loader.load();
        Object controller = loader.getController();
        if (controller instanceof StartPanel) {
            ((StartPanel) controller).setStage(stage);
        } else if (controller instanceof SignUpPanel) {
            ((SignUpPanel) controller).setStage(stage);
        } else if (controller instanceof LoginPanel) {
            ((LoginPanel) controller).setStage(stage);
        } else if (controller instanceof DashboardPanel) {
            ((DashboardPanel) controller).setStage(stage);
        }
        stage.setScene(new Scene(root));
    }
}