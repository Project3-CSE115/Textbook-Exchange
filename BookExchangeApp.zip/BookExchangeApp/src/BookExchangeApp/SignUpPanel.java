package BookExchangeApp;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;

public class SignUpPanel {
    private Stage stage;
    private final UserAccount engine = new UserAccount();

    @FXML 
    private TextField nameField, idField, emailField, contactField;
    @FXML 
    private PasswordField passField;
    @FXML 
    private ComboBox<String> typeBox;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    
    @FXML
    private void registerUser() {
        if (nameField.getText().isEmpty() || idField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Name and ID cannot be empty!");
            return;
        }
        if (engine.isIdDuplicate(idField.getText())) {
            showAlert(Alert.AlertType.ERROR, "Student ID already exists!");
            return;
        }

        User newUser = typeBox.getValue().equals("Seller")
                ? new Seller(nameField.getText(), idField.getText(), passField.getText(), emailField.getText(), contactField.getText())
                : new Student(nameField.getText(), idField.getText(), passField.getText(), emailField.getText(), contactField.getText());

        engine.registerUser(newUser);
        showAlert(Alert.AlertType.INFORMATION, "Account created successfully!");

        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();
            LoginPanel controller = loader.getController();
            controller.setStage(stage);  // Pass the stage to the LoginPanel
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Failed to load Login screen.");
        }
    }
    
    @FXML
    private void showStartMenu() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Start.fxml"));
            Parent root = loader.load();
            StartPanel controller = loader.getController();
            controller.setStage(stage);  
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();  
        }
    }
    
    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message);
        alert.showAndWait();
    }

    private void loadScene(String fxml) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();
            stage.setScene(new Scene(root));
        } catch (Exception e) { e.printStackTrace(); }
    }
}