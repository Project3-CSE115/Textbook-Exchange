package BookExchangeApp;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;

public class LoginPanel {
    private Stage stage;
    private final UserAccount engine = new UserAccount();

    @FXML private TextField idField;
    @FXML private PasswordField passField;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void login() {
        UserAccount sharedEngine = new UserAccount();  
        if (sharedEngine.login(idField.getText(), passField.getText())) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
                Parent root = loader.load();
                DashboardPanel dashboard = loader.getController();
                dashboard.setStage(stage);
                dashboard.setEngine(sharedEngine);  
                stage.setScene(new Scene(root));
            } catch (Exception e) { e.printStackTrace(); }
        } else {
            showAlert(Alert.AlertType.ERROR, "Invalid ID or Password!");
        }
    }

    @FXML
    private void showStartMenu() {
        loadScene("Start.fxml");
    }

    private void loadScene(String fxml) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();
            Object controller = loader.getController();
            if (controller instanceof DashboardPanel) {
                ((DashboardPanel) controller).setStage(stage);
            } else if (controller instanceof StartPanel) {
                ((StartPanel) controller).setStage(stage);
            }
            stage.setScene(new Scene(root));
        } catch (Exception e) { e.printStackTrace(); }
    }
    
    
    private void showAlert(Alert.AlertType type, String message) {
        new Alert(type, message).showAndWait();
    }
}