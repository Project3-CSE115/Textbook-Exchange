package BookExchangeApp;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;

public class DashboardPanel {
    private Stage stage;
    private UserAccount engine;

    public void setEngine(UserAccount engine) {
        this.engine = engine;
    }

    @FXML private VBox content;
    @FXML private ScrollPane contentScroll;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void showSellForm() {
        content.getChildren().clear();
        TextField title = new TextField(); title.setPromptText("Book Title");
        TextField author = new TextField(); author.setPromptText("Author");
        TextField originalPrice = new TextField(); originalPrice.setPromptText("Original Price (BDT)");
        ComboBox<String> condition = new ComboBox<>();
        condition.getItems().addAll("New", "Good", "Fair", "Poor");
        condition.setValue("Good");

        Button post = new Button("Post for Sale");
        post.setOnAction(e -> {
            try {
                double op = Double.parseDouble(originalPrice.getText());
                double rec = Book.getRecommendedPrice(op, condition.getValue());
                Book book = new Book(title.getText(), author.getText(), condition.getValue(), rec, engine.getThisUser().getID());
                engine.listBook(book);
                showAlert(Alert.AlertType.INFORMATION, "Book listed successfully at " + rec + " BDT!");
            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Invalid price!");
            } catch (DuplicateBookException ex) {
                showAlert(Alert.AlertType.ERROR, ex.getMessage());
            } finally {
                showMarketplace();  
            }
        });

        content.getChildren().addAll(
                new Label("List a New Book for Sale"),
                title, author, originalPrice, condition, post
        );
    }

    
    @FXML
    private void showMarketplace() {
        content.getChildren().clear();
        content.getChildren().add(new Label("Available Books:"));
        
        
        
        for (Book b : engine.getBooks()) {
            HBox card = new HBox(20);
     
            card.setStyle("-fx-background-color: #FAF9F6; " +
                          "-fx-border-color: #BFA880; " +
                          "-fx-border-width: 2; " +
                          "-fx-padding: 20; " +
                          "-fx-background-radius: 10; " +
                          "-fx-border-radius: 10; " +
                          "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 2, 2);"); // optional soft shadow

            VBox info = new VBox(5);
            
            info.setStyle("-fx-font-size: 18px; -fx-text-fill: #4E342E;");

            info.getChildren().addAll(
                    new Label("Title: " + b.getTitle()),
                    new Label("Author: " + b.getAuthor()),
                    new Label("Condition: " + b.getCondition()),
                    new Label("Price: " + b.getPrice() + " BDT")
            );

          
            for (javafx.scene.Node label : info.getChildren()) {
                if (label instanceof Label) {
                    ((Label) label).setStyle("-fx-font-weight: bold;"); // optional: bold titles
                }
            }

            VBox actions = new VBox(10);
            Button contact = new Button("Contact Seller");
            contact.setStyle("-fx-background-color: #8B6F47; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20;");
            
            contact.setOnAction(e -> {
                User seller = engine.findUserByID(b.getSellerID());
                if (seller != null) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Seller Contact");
                    alert.setContentText("Name: " + seller.getName() + "\nEmail: " + seller.getEmail() + "\nContact: " + seller.getContact());
                    alert.show();
                }
            });

            Button buy = new Button("Buy Now");
            buy.setStyle("-fx-background-color: #6B705C; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-background-radius: 5;");

            buy.setOnAction(e -> {
                engine.buyBook(b.getTitle());
                showAlert(Alert.AlertType.INFORMATION, "Book purchased and removed from listings!");
                showMarketplace();
            });

            actions.getChildren().addAll(contact, buy);
            card.getChildren().addAll(info, actions);
            content.getChildren().add(card);
        }
    }

    @FXML
    private void logout() {
        engine.logout();
        loadScene("Start.fxml");
    }

    private void loadScene(String fxml) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();
            stage.setScene(new Scene(root));
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void showAlert(Alert.AlertType type, String message) {
        new Alert(type, message).showAndWait();
    }
}