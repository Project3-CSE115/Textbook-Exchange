package BookExchangeApp;

public class Student extends User {
	
	// constructor //
	
    public Student(String username, String ID, String password, String email, String contact) {
        super(username, ID, password, email, contact);
    }

    @Override
    public void displayUserProfile() {
        System.out.println("==========================");
        System.out.println("\t\tSTUDENT PROFILE");
        System.out.println("Name\t: " + username);
        System.out.println("Student ID: " + ID);
        System.out.println("Email\t: " + email);
        System.out.println("Contact\t: " + contact);
        System.out.println("==========================");
    }
}