package BookExchangeApp;

import java.io.Serializable;

public class Book implements Serializable {
    private String title;
    private String author;
    private String condition;
    private double price;
    private String sellerID;

    public Book(String title, String author, String condition, double price, String sellerID) {
        this.title = title;
        this.author = author;
        this.condition = condition;
        this.price = price;
        this.sellerID = sellerID;
    }

    public static double getRecommendedPrice(double originalPrice, String condition) {
        double factor = switch (condition.toLowerCase()) {
            case "new" -> 0.9;
            case "good" -> 0.7;
            case "fair" -> 0.5;
            case "poor" -> 0.3;
            default -> 0.5;
        };
        return originalPrice * factor;
    }

    // Getters //
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getCondition() { return condition; }
    public double getPrice() { return price; }
    public String getSellerID() { return sellerID; }

    @Override
    public String toString() {
        return String.format("**%s** by %s | Condition: %s | Price: %.2f BDT | Seller: %s",
                title, author, condition, price, sellerID);
    }

    public String toTxt() {
        return title + "|" + author + "|" + condition + "|" + price + "|" + sellerID;
    }
}