package BookExchangeApp;

public interface Archive {
    void saveData();
    void loadData();
}