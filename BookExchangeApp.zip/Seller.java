package BookExchangeApp;

public class Seller extends User {
    public Seller(String username, String ID, String password, String email, String contact) {
        super(username, ID, password, email, contact);
    }

    @Override
    public void displayUserProfile() {
        System.out.println("\n--- SELLER PROFILE ---");
        System.out.println("Name: " + username + "\nID: " + ID + "\nEmail: " + email + "\nContact: " + contact);
    }
}