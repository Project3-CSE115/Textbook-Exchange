package BookExchangeApp;

public class Student extends User {
    public Student(String username, String ID, String password, String email, String contact) {
        super(username, ID, password, email, contact);
    }

    @Override
    public void displayUserProfile() {
        System.out.println("\n--- STUDENT PROFILE ---");
        System.out.println("Name: " + username + "\nID: " + ID + "\nEmail: " + email + "\nContact: " + contact);
    }
}
