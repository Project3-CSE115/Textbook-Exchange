package BookExchangeApp;

import java.util.ArrayList;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class GUI extends Application {
    UserAccount engine = new UserAccount();
    Stage window;

    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;
        window.setTitle("NSU Book Exchange");
        window.setWidth(900);
        window.setHeight(650);
        showStartMenu(); //Program starts here
        window.show();
    }

    private void styleButton(Button btn) {
        btn.setMaxWidth(Double.MAX_VALUE); //Makes button fill the width of its container
        btn.setPadding(new Insets(15));
        btn.setStyle("-fx-background-color: #2C3E50; -fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold; -fx-cursor: hand;");
    }

    private void styleInput(Control input) {
        input.setMaxWidth(Double.MAX_VALUE);
        input.setPrefHeight(50); // Makes the box taller
        input.setStyle("-fx-font-size: 16px;"); // Makes the typing/prompt text bigger
    }

    // --- SCREEN 1: START MENU ---
    private void showStartMenu() {
        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        Label welcomeLabel = new Label("Welcome to NSU Book Exchange");
        welcomeLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Button goToLogin = new Button("Sign In");
        Button goToSignUp = new Button("Sign Up (New User)");

        styleButton(goToLogin); 
        styleButton(goToSignUp);

        goToLogin.setMinWidth(150);
        goToSignUp.setMinWidth(150);

        goToLogin.setOnAction(e -> showLogin());
        goToSignUp.setOnAction(e -> showSignUp());

        root.getChildren().addAll(welcomeLabel, goToLogin, goToSignUp);
        window.setScene(new Scene(root, 450, 400));
    }

    private void showBuyForm(Book targetBook) {
        Stage popup = new Stage();
        popup.setTitle("Send Buy Offer");

        VBox form = new VBox(20);
        form.setPadding(new Insets(30));
        form.setAlignment(Pos.CENTER);
        form.setStyle("-fx-background-color: #ECF0F1;");
        
        Label header = new Label("Send Buy Offer for:");
        header.setStyle("-fx-font-size: 18px;");
        Label bookName = new Label(targetBook.getTitle());
        bookName.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        Label priceLabel = new Label("Price: " + targetBook.getPrice() + " BDT");
        priceLabel.setStyle("-fx-font-size: 20px; -fx-text-fill: #27AE60; -fx-font-weight: bold;");

        Button confirmBtn = new Button("Confirm Purchase Offer");
        styleButton(confirmBtn);
        confirmBtn.setStyle(confirmBtn.getStyle() + "-fx-background-color: #27AE60;");

        confirmBtn.setOnAction(e -> {
            ExchangeOffer buyOffer = new ExchangeOffer(
                engine.getThisUser().getID(), 
                targetBook.getSellerID(), 
                targetBook.getTitle(), 
                "CASH",
                "BUY"
            );

            engine.getOffers().add(buyOffer); 
            
            engine.saveExchanges(); 
            
            new Alert(Alert.AlertType.INFORMATION, "Buy offer sent successfully!").show();
            popup.close();
        });

        form.getChildren().addAll(header, bookName, priceLabel, confirmBtn);
        popup.setScene(new Scene(form, 450, 350));
        popup.show();
    }

    private void showExchangeForm(Book targetBook) {
        Stage popup = new Stage();
        popup.setTitle("Propose Exchange");

        VBox form = new VBox(20);
        form.setPadding(new Insets(30));
        form.setAlignment(Pos.CENTER);
        form.setStyle("-fx-background-color: #ECF0F1;");
        
        Label header = new Label("Exchanging for:");
        header.setStyle("-fx-font-size: 18px;");
        Label bookName = new Label(targetBook.getTitle());
        bookName.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #2C3E50;");

        TextField myBookTitle = new TextField(); 
        myBookTitle.setPromptText("Enter Your Book Title");
        styleInput(myBookTitle); // Uses the big input style
        
        Button submit = new Button("Send Exchange Proposal");
        styleButton(submit);
        submit.setStyle(submit.getStyle() + "-fx-background-color: #2980B9;"); // Blue

        submit.setOnAction(e -> {
            try {
                engine.proposeExchange(targetBook, myBookTitle.getText());
                new Alert(Alert.AlertType.INFORMATION, "Proposal sent to the owner!").show();
                popup.close();
            } catch (InvalidExchangeException ex) {
                new Alert(Alert.AlertType.ERROR, ex.getMessage()).show();
            }
        });

        form.getChildren().addAll(header, bookName, new Label("Your Book:"), myBookTitle, submit);
        
        popup.setScene(new Scene(form, 500, 450)); // Bigger popup window
        popup.show();
    }

    // --- SCREEN 2: SIGN UP ---
    private void showSignUp() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(20));

        TextField nameField = new TextField(); nameField.setPromptText("Full Name");
        TextField idField = new TextField(); idField.setPromptText("Student ID");
        PasswordField passField = new PasswordField(); passField.setPromptText("Password");
        TextField emailField = new TextField(); emailField.setPromptText("Email Address");
        TextField contactField = new TextField(); contactField.setPromptText("Contact Number");

        // User Type Selection
        Label typeLabel = new Label("Register as:");
        ComboBox<String> typeBox = new ComboBox<>();
        typeBox.getItems().addAll("Student", "Seller");
        typeBox.setValue("Student");

        Button registerBtn = new Button("Create Account");
        Button backBtn = new Button("Back");

        registerBtn.setOnAction(e -> {
            String id = idField.getText();
            if (id.isEmpty() || nameField.getText().isEmpty()) {
                new Alert(Alert.AlertType.WARNING, "Name and ID cannot be empty!").show();
                return;
            }

            //duplicate check
            if (engine.isIdDuplicate(id)) {
                new Alert(Alert.AlertType.ERROR, "Error: Student ID already exists!").show();
            } else {
                User newUser;
                if (typeBox.getValue().equals("Seller")) {
                    newUser = new Seller(nameField.getText(), id, passField.getText(), emailField.getText(), contactField.getText());
                } else {
                    newUser = new Student(nameField.getText(), id, passField.getText(), emailField.getText(), contactField.getText());
                }
                
                engine.registerUser(newUser);
                new Alert(Alert.AlertType.INFORMATION, "Account Created Successfully!").show();
                showLogin(); //Going to login after signing up
            }
        });

        backBtn.setOnAction(e -> showStartMenu());

        root.getChildren().addAll(new Label("Create New Account"), nameField, idField, passField, emailField, contactField, typeLabel, typeBox, registerBtn, backBtn);
        window.setScene(new Scene(root, 500, 600));
    }

    // --- SCREEN 3: SIGN IN ---
    private void showLogin() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(20));

        Label header = new Label("Sign In to Continue");
        header.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        
        TextField idField = new TextField(); idField.setPromptText("Student ID");
        PasswordField passField = new PasswordField(); passField.setPromptText("Password");
        Button loginBtn = new Button("Login");
        Button backBtn = new Button("Back");

        loginBtn.setOnAction(e -> {
            if (engine.login(idField.getText(), passField.getText())) {
                showDashboard();
            } else {
                new Alert(Alert.AlertType.ERROR, "Invalid ID or Password!").show();
            }
        });

        backBtn.setOnAction(e -> showStartMenu());

        styleInput(idField);
        styleInput(passField);
        styleButton(loginBtn);

        root.getChildren().addAll(new Label("Sign In to Continue"), idField, passField, loginBtn, backBtn);
        window.setScene(new Scene(root, 500, 400));
    }

    // --- SCREEN 4: DASHBOARD (Marketplace/Selling) ---
    private void showDashboard() {
        BorderPane layout = new BorderPane();
        VBox sideMenu = new VBox(10);
        sideMenu.setPadding(new Insets(10));
        sideMenu.setMinWidth(250);
        
        Button viewBtn = new Button("Marketplace");
        Button exchangeBtn = new Button("Exchange Hub");
        Button sellBtn = new Button("Sell a Book");
        Button pendingBtn = new Button("Pending Offers");
        Button logoutBtn = new Button("Logout");
        viewBtn.setMinWidth(100); sellBtn.setMinWidth(100); logoutBtn.setMinWidth(100);
        
        sideMenu.getChildren().addAll(viewBtn, sellBtn, logoutBtn);

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setFillWidth(true);

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent; -fx-background: #ECF0F1;");
        layout.setCenter(scrollPane);

        //Selling logic with Recommended Price
        sellBtn.setOnAction(e -> {
            content.getChildren().clear();
            content.setSpacing(20); // Add space between form elements

            // Big Section Header
            Label header = new Label("List a New Book for Sale");
            header.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: #2C3E50;");

            // Input Fields
            TextField title = new TextField(); 
            title.setPromptText("Book Title");
            
            TextField author = new TextField(); 
            author.setPromptText("Author Name");
            
            TextField originalPrice = new TextField(); 
            originalPrice.setPromptText("Original Price (BDT)");
            
            ComboBox<String> cond = new ComboBox<>();
            cond.getItems().addAll("New", "Good", "Fair", "Poor");
            cond.setValue("Good");

            // Apply big styles using the helpers
            styleInput(title);
            styleInput(author);
            styleInput(originalPrice);
            styleInput(cond); // Ensure styleInput handles ComboBox as well

            // Big Post Button
            Button postBtn = new Button("Post for Sale");
            styleButton(postBtn); // Uses your big 18px font style
            postBtn.setStyle(postBtn.getStyle() + "-fx-background-color: #27AE60;"); // Make this button Green

            postBtn.setOnAction(ev -> {
                try {
                    if(title.getText().isEmpty() || author.getText().isEmpty()) {
                        new Alert(Alert.AlertType.WARNING, "Please fill in all fields!").show();
                        return;
                    }
                    double op = Double.parseDouble(originalPrice.getText());
                    double rec = Book.getRecommendedPrice(op, cond.getValue());
                    
                    engine.listBook(new Book(title.getText(), author.getText(), cond.getValue(), rec, engine.getThisUser().getID()));
                    
                    new Alert(Alert.AlertType.INFORMATION, "Success! Book listed at: " + rec + " BDT").show();
                    content.getChildren().clear();
                    viewBtn.fire(); // Automatically switch to Marketplace to see the new listing
                } catch (Exception ex) {
                    new Alert(Alert.AlertType.ERROR, "Invalid price format!").show();
                }
            });

            // Add everything to content
            content.getChildren().addAll(header, 
                new Label("Book Details:"), title, author, 
                new Label("Condition:"), cond, 
                new Label("Price Information:"), originalPrice, 
                postBtn
            );

            // Style the small sub-labels
            content.getChildren().forEach(node -> {
                if (node instanceof Label && node != header) {
                    node.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #7F8C8D;");
                }
            });
        });

        //Buying/Communication Logic
        viewBtn.setOnAction(e -> {
            content.getChildren().clear();
            content.setSpacing(20);

            Label sectionHeader = new Label("Current Marketplace Listings");
            sectionHeader.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: #2C3E50;");
            content.getChildren().add(sectionHeader);

            for (Book b : engine.getBooks()) {
                HBox card = new HBox(20);
                card.setAlignment(Pos.CENTER_LEFT);
                card.setPadding(new Insets(20));
                card.setMaxWidth(Double.MAX_VALUE);
                card.setStyle("-fx-border-color: #BDC3C7; -fx-border-radius: 10; -fx-background-color: white; " +
                            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 0, 5);");

                VBox details = new VBox(8);
                Label titleLabel = new Label(b.getTitle());
                titleLabel.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");
                Label priceLabel = new Label("Price: " + b.getPrice() + " BDT");
                priceLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #27AE60; -fx-font-weight: bold;");
                details.getChildren().addAll(titleLabel, priceLabel);

                Region spacer = new Region();
                HBox.setHgrow(spacer, Priority.ALWAYS);

                // CHANGED: This button now sends an offer instead of just showing contact info
                Button contactBtn = new Button("Send Offer"); 
                styleButton(contactBtn);
                contactBtn.setMinWidth(180);

                contactBtn.setText("Buy This Book"); // Change text to be clear
                contactBtn.setOnAction(ev -> {
                    if (b.getSellerID().equals(engine.getThisUser().getID())) {
                        new Alert(Alert.AlertType.WARNING, "You cannot buy your own book!").show();
                    } else {
                        showBuyForm(b); // Opens the new Buy form
                    }
                });

                card.getChildren().addAll(details, spacer, contactBtn);
                content.getChildren().add(card);
            }
        });

        exchangeBtn.setMinWidth(100);
        sideMenu.getChildren().add(1, exchangeBtn);

        exchangeBtn.setOnAction(e -> {
            content.getChildren().clear();
            content.setSpacing(20);

            Label header = new Label("Exchange Hub: Propose a Trade");
            header.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: #2C3E50;");
            content.getChildren().add(header);

            for (Book b : engine.getBooks()) {
                if (b.getSellerID().equals(engine.getThisUser().getID())) continue;

                HBox card = new HBox(20);
                card.setAlignment(Pos.CENTER_LEFT);
                card.setPadding(new Insets(20));
                card.setMaxWidth(Double.MAX_VALUE);
                card.setStyle("-fx-border-color: #7F8C8D; -fx-border-radius: 10; -fx-background-color: #FAF9F6; " +
                            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 8, 0, 0, 4);");
                
                VBox details = new VBox(8);
                Label bTitle = new Label(b.getTitle());
                bTitle.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");
                
                Label bSeller = new Label("Owner ID: " + b.getSellerID());
                bSeller.setStyle("-fx-font-size: 16px; -fx-text-fill: #7F8C8D;");
                
                details.getChildren().addAll(bTitle, bSeller);
                
                Region spacer = new Region();
                HBox.setHgrow(spacer, Priority.ALWAYS);

                Button offerBtn = new Button("Offer Exchange");
                styleButton(offerBtn);
                offerBtn.setStyle(offerBtn.getStyle() + "-fx-background-color: #6B705C;"); // Muted Earthy Green
                offerBtn.setMinWidth(200);

                offerBtn.setOnAction(ev -> showExchangeForm(b));

                card.getChildren().addAll(details, spacer, offerBtn);
                content.getChildren().add(card);
            }
        });

        pendingBtn.setMinWidth(100);
        sideMenu.getChildren().add(2, pendingBtn); 

        pendingBtn.setOnAction(e -> {
            content.getChildren().clear();
            content.setSpacing(20);

            Label header = new Label("Exchanges Proposed to You");
            header.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: #2C3E50;");
            content.getChildren().add(header);

            ArrayList<ExchangeOffer> myOffers = engine.getMyOffers();
            if (myOffers.isEmpty()) {
                Label emptyLabel = new Label("No pending offers at the moment.");
                emptyLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #7F8C8D;");
                content.getChildren().add(emptyLabel);
            }

            for (ExchangeOffer offer : engine.getMyOffers()) {
                if (!offer.getStatus().equals("Pending")) continue;

                VBox offerCard = new VBox(10);
                offerCard.setPadding(new Insets(15));
                offerCard.setMaxWidth(Double.MAX_VALUE);
                
                // Header based on offer type
                String typeLabel = offer.getOfferType().equalsIgnoreCase("BUY") ? "[BUY REQUEST]" : "[EXCHANGE REQUEST]";
                Label typeHeader = new Label(typeLabel + " from " + offer.getSenderID());
                typeHeader.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #2980B9;");

                Label desc = new Label();
                if (offer.getOfferType().equalsIgnoreCase("BUY")) {
                    desc.setText("Wants to buy your book: " + offer.getWantedBookTitle());
                } else {
                    desc.setText("Wants: " + offer.getWantedBookTitle() + "\nOffers: " + offer.getOfferedBookTitle());
                }
                desc.setStyle("-fx-font-size: 16px;");

                HBox actionBtns = new HBox(15);
                Button approve = new Button("Approve");
                Button reject = new Button("Decline");
                
                // Apply large styles
                styleButton(approve);
                styleButton(reject);
                
                approve.setStyle(approve.getStyle() + "-fx-background-color: #27AE60;"); // Green
                reject.setStyle(reject.getStyle() + "-fx-background-color: #C0392B;");   // Red
                
                HBox.setHgrow(approve, Priority.ALWAYS);
                HBox.setHgrow(reject, Priority.ALWAYS);

                approve.setOnAction(ev -> {
                    offer.setStatus("Approved");
                    
                    // REMOVE THE BOOK FROM MARKETPLACE/EXCHANGE HUB
                    engine.removeBookByTitle(offer.getWantedBookTitle());
                    
                    engine.saveExchanges();
                    new Alert(Alert.AlertType.INFORMATION, "Offer Approved! The book has been removed from listings.").show();
                    pendingBtn.fire(); // Refresh the view
                });

                reject.setOnAction(ev -> {
                    offer.setStatus("Rejected");
                    engine.saveExchanges();
                    pendingBtn.fire(); 
                });

                actionBtns.getChildren().addAll(approve, reject);
                offerCard.getChildren().addAll(typeHeader, desc, actionBtns);
                content.getChildren().add(offerCard);
            }
        });

        logoutBtn.setOnAction(e -> { engine.logout(); showStartMenu(); });

        styleButton(viewBtn);
        styleButton(exchangeBtn);
        styleButton(pendingBtn);
        styleButton(sellBtn);
        styleButton(logoutBtn);
        logoutBtn.setStyle(logoutBtn.getStyle() + "-fx-background-color: #C0392B;");
        layout.setLeft(sideMenu);
        layout.setCenter(new ScrollPane(content));
        window.setScene(new Scene(layout, 900, 650));
    }

    public static void main(String[] args) { launch(args); }
}