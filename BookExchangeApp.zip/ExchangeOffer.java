package BookExchangeApp;

import java.io.Serializable;

public class ExchangeOffer implements Serializable {
    private String senderID;
    private String receiverID;
    private String wantedBookTitle;
    private String offeredBookTitle;
    private String status;// "Pending", "Approved", or "Rejected"
    private String offerType;

    public ExchangeOffer(String senderID, String receiverID, String wantedBookTitle, String offeredBookTitle, String offerType) {
        this.senderID = senderID;
        this.receiverID = receiverID;
        this.wantedBookTitle = wantedBookTitle;
        this.offeredBookTitle = offeredBookTitle;
        this.status = "Pending";
        this.offerType = offerType;
    }
    
    // Update your toTxt() to include the type
    public String toTxt() {
        return senderID + "|" + receiverID + "|" + wantedBookTitle + "|" + offeredBookTitle + "|" + status + "|" + offerType;
    }

    // Getters
    public String getSenderID() { return senderID; }
    public String getReceiverID() { return receiverID; }
    public String getWantedBookTitle() { return wantedBookTitle; }
    public String getOfferedBookTitle() { return offeredBookTitle; }
    public String getStatus() { return status; }
    public String getOfferType() {return offerType; }
    public void setStatus(String status) { this.status = status; }

}
