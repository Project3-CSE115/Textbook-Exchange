package BookExchangeApp;

//Custom exception to handle wrong trading actions
public class InvalidExchangeException extends Exception {
    public InvalidExchangeException(String message) {
        super(message);
    }
}
